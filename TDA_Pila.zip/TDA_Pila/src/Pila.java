
/**
 *
 * @author César Álvarez
 */
public class Pila {
    private int Data[];
    private int tope;
    private int eleElim;
 
    public Pila(int tam){
       Data=new int[tam]; 
       tope=-1;
    }
    
    public boolean insertar(int valor){
        if(tope==Data.length-1){
            return false;
        }
        tope++;
        Data[tope]=valor;
        return true;
    }
    public boolean eliminar(){
        if(tope==-1){
            return false;
        }
        eleElim=Data[tope];
        tope--;
        return true;
    }
    public int mostrarEliminado(){
        return eleElim;
    }
    
    public int[] pilaCopiar(){
        return Data;
    }
    public int TOS(){
        return tope;
    }
}
